/*
  === SERVER-SIDE IMPLEMENTATION ===
  This file represents the backend logic needed to connect to MongoDB.
  In a production environment, run this with: `node server.js`
  Ensure you have a .env file with MONGODB_URI.
*/

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const app = express();
app.use(express.json());
app.use(cors());

// --- CONFIG ---
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'secret_key_change_me';
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/jobnexus';

// --- MONGODB CONNECTION ---
mongoose.connect(MONGODB_URI)
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.error('MongoDB Connection Error:', err));

// --- SCHEMAS ---

const UserSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  phoneNumber: { type: String, required: true },
  address: String,
  education: {
    degree: String,
    class12: String,
    class10: String
  },
  resumeName: String,
  createdAt: { type: Date, default: Date.now }
});

const AdminSchema = new mongoose.Schema({
  companyName: { type: String, required: true },
  companyEmail: { type: String, required: true }, // Unique identifier usually
  employerId: { type: String, required: true, unique: true },
  employerName: { type: String, required: true },
  password: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

const JobSchema = new mongoose.Schema({
  employerId: { type: String, required: true },
  employerName: String,
  companyName: String,
  title: { type: String, required: true },
  description: { type: String, required: true },
  experienceRequired: String,
  skillset: [String],
  startDate: Date,
  endDate: Date,
  salary: String,
  jobType: String,
  location: String,
  openings: { type: Number, default: 1 },
  applicationCount: { type: Number, default: 0 },
  isWithdrawn: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

const ApplicationSchema = new mongoose.Schema({
  jobId: { type: mongoose.Schema.Types.ObjectId, ref: 'Job' },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  userEmail: String,
  status: { type: String, default: 'applied' },
  appliedAt: { type: Date, default: Date.now }
});

const User = mongoose.model('User', UserSchema);
const Admin = mongoose.model('Admin', AdminSchema);
const Job = mongoose.model('Job', JobSchema);
const Application = mongoose.model('Application', ApplicationSchema);

// --- ROUTES ---

// Admin Auth
app.post('/api/admin/signup', async (req, res) => {
  try {
    const { password, ...rest } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const admin = await Admin.create({ ...rest, password: hashedPassword });
    const token = jwt.sign({ id: admin._id, role: 'ADMIN' }, JWT_SECRET);
    res.json({ success: true, data: { ...admin.toObject(), token } });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post('/api/admin/login', async (req, res) => {
  try {
    const { employerId, password } = req.body;
    const admin = await Admin.findOne({ employerId });
    if (!admin || !await bcrypt.compare(password, admin.password)) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: admin._id, role: 'ADMIN' }, JWT_SECRET);
    res.json({ success: true, data: { ...admin.toObject(), token } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// User Auth
app.post('/api/user/signup', async (req, res) => {
  try {
    const { password, ...rest } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ ...rest, password: hashedPassword });
    const token = jwt.sign({ id: user._id, role: 'USER' }, JWT_SECRET);
    res.json({ success: true, data: { ...user.toObject(), token } });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.post('/api/user/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !await bcrypt.compare(password, user.password)) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user._id, role: 'USER' }, JWT_SECRET);
    res.json({ success: true, data: { ...user.toObject(), token } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Jobs
app.get('/api/jobs', async (req, res) => {
  try {
    const jobs = await Job.find().sort({ createdAt: -1 });
    res.json({ success: true, data: jobs });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.post('/api/jobs', async (req, res) => {
  try {
    const job = await Job.create(req.body);
    res.json({ success: true, data: job });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
});

app.put('/api/jobs/:id/withdraw', async (req, res) => {
  try {
    const job = await Job.findByIdAndUpdate(req.params.id, { isWithdrawn: true }, { new: true });
    res.json({ success: true, data: job });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Applications
app.post('/api/jobs/:id/apply', async (req, res) => {
  try {
    const { userId, userEmail } = req.body;
    const existing = await Application.findOne({ jobId: req.params.id, userId });
    if (existing) return res.status(400).json({ success: false, message: 'Already applied' });

    await Application.create({ jobId: req.params.id, userId, userEmail });
    await Job.findByIdAndUpdate(req.params.id, { $inc: { applicationCount: 1 } });
    
    // Mock Email Sending Logic
    console.log(`Sending confirmation email to ${userEmail} for Job ID ${req.params.id}`);

    res.json({ success: true, message: 'Application submitted' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
