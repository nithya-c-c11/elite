export enum UserRole {
  ADMIN = 'ADMIN',
  USER = 'USER',
  GUEST = 'GUEST'
}

export enum JobType {
  FULL_TIME = 'Full Time',
  PART_TIME = 'Part Time',
  INTERNSHIP = 'Internship',
  CONTRACT = 'Contract'
}

export interface AdminProfile {
  _id: string;
  companyEmail: string;
  companyName: string;
  employerId: string;
  employerName: string;
  password?: string; // Optional in frontend state for security
  token?: string;
}

export interface UserProfile {
  _id: string;
  email: string;
  name: string;
  education: {
    degree: string;
    class12: string;
    class10: string;
  };
  phoneNumber: string;
  address: string;
  password?: string;
  resumeName: string | null;
  token?: string;
}

export interface JobPost {
  _id: string;
  employerId: string;
  employerName: string;
  companyName: string;
  title: string;
  description: string;
  experienceRequired: string;
  skillset: string[];
  startDate: string;
  endDate: string;
  salary: string;
  jobType: JobType;
  location: string;
  openings: number;
  applicationCount: number;
  isWithdrawn: boolean;
  createdAt: string; // ISO Date string from MongoDB
}

export interface Application {
  _id: string;
  jobId: string;
  userId: string;
  userEmail: string;
  appliedAt: string;
  status: 'applied' | 'viewed' | 'rejected' | 'accepted';
}

export interface JobFilters {
  companyName: string;
  location: string;
  experience: string;
  role: string;
  skills: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
}
