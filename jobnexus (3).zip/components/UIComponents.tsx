import React, { ReactNode } from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

export const Input: React.FC<InputProps> = ({ label, error, className, ...props }) => (
  <div className="mb-5 group">
    <label className="block text-sm font-semibold text-slate-600 mb-1.5 transition-colors group-focus-within:text-indigo-600">
      {label}
    </label>
    <input
      className={`w-full px-4 py-3 bg-white border rounded-xl text-slate-800 placeholder-slate-400 transition-all duration-200 ease-in-out
        focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none
        ${error 
          ? 'border-red-300 focus:border-red-500 focus:ring-red-200' 
          : 'border-slate-200 hover:border-slate-300'
        } ${className}`}
      {...props}
    />
    {error && (
      <p className="text-xs font-medium text-red-500 mt-1.5 flex items-center animate-fade-in">
        <span className="mr-1">⚠️</span> {error}
      </p>
    )}
  </div>
);

interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
  error?: string;
}

export const TextArea: React.FC<TextAreaProps> = ({ label, error, className, ...props }) => (
  <div className="mb-5 group">
    <label className="block text-sm font-semibold text-slate-600 mb-1.5 transition-colors group-focus-within:text-indigo-600">
      {label}
    </label>
    <textarea
      className={`w-full px-4 py-3 bg-white border rounded-xl text-slate-800 placeholder-slate-400 transition-all duration-200 ease-in-out
        focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none
        ${error 
          ? 'border-red-300 focus:border-red-500 focus:ring-red-200' 
          : 'border-slate-200 hover:border-slate-300'
        } ${className}`}
      {...props}
    />
    {error && <p className="text-xs font-medium text-red-500 mt-1.5 animate-fade-in">{error}</p>}
  </div>
);

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'outline' | 'ghost';
  loading?: boolean;
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  loading, 
  className, 
  disabled, 
  fullWidth,
  ...props 
}) => {
  // Base styles with 3D "press" effect logic (transform active)
  const baseStyles = `
    relative font-bold rounded-xl transition-all duration-200 flex items-center justify-center
    active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed disabled:active:scale-100
    focus:outline-none focus:ring-2 focus:ring-offset-2
    ${fullWidth ? 'w-full' : ''}
  `;
  
  const variants = {
    primary: "bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/50 hover:-translate-y-0.5 border border-transparent focus:ring-indigo-500 py-3 px-6",
    secondary: "bg-white text-slate-700 border border-slate-200 shadow-sm hover:border-slate-300 hover:bg-slate-50 hover:text-indigo-600 focus:ring-slate-200 py-2.5 px-5",
    danger: "bg-gradient-to-r from-red-500 to-rose-600 text-white shadow-lg shadow-red-500/30 hover:shadow-red-500/50 hover:-translate-y-0.5 focus:ring-red-500 py-2 px-4 text-sm",
    outline: "border-2 border-slate-300 text-slate-600 bg-transparent hover:border-indigo-500 hover:text-indigo-600 focus:ring-indigo-500 py-2 px-4",
    ghost: "bg-transparent text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 py-2 px-4"
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${className}`} 
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <span className="flex items-center">
          <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-current" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Processing...
        </span>
      ) : children}
    </button>
  );
};

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
}

export const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 perspective-1000">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity animate-fade-in" 
        onClick={onClose}
      />
      
      {/* Modal Content */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-fade-in border border-slate-100 transform transition-all scale-100">
        <div className="flex justify-between items-center p-6 border-b border-slate-100 bg-gradient-to-r from-slate-50 to-white rounded-t-2xl">
          <h3 className="text-xl font-bold text-slate-800 bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600">
            {title}
          </h3>
          <button 
            onClick={onClose} 
            className="p-2 rounded-full text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
        <div className="p-6">
          {children}
        </div>
      </div>
    </div>
  );
};