import React, { useState, useEffect, useMemo } from 'react';
import { 
  UserRole, 
  AdminProfile, 
  UserProfile, 
  JobPost, 
  JobType, 
  JobFilters 
} from './types';
import { Input, Button, Modal } from './components/UIComponents';
import { generateJobDescription } from './services/geminiService';
import { api, validators } from './services/api';
import { 
  Briefcase, 
  Building2, 
  MapPin, 
  DollarSign, 
  Search, 
  Filter, 
  Heart, 
  FileText, 
  LogOut,
  Wand2,
  ArrowRight,
  Stars,
  ShieldCheck,
  TrendingUp,
  CheckCircle
} from 'lucide-react';

function App() {
  // --- STATE ---
  const [currentView, setCurrentView] = useState<'landing' | 'admin-auth' | 'admin-dash' | 'user-auth' | 'user-dash'>('landing');
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  
  const [currentUser, setCurrentUser] = useState<AdminProfile | UserProfile | null>(null);
  const [userRole, setUserRole] = useState<UserRole>(UserRole.GUEST);
  
  const [jobs, setJobs] = useState<JobPost[]>([]);
  const [loading, setLoading] = useState(false);
  const [savedJobs, setSavedJobs] = useState<string[]>([]);

  // --- FORMS & ERRORS ---
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [jobForm, setJobForm] = useState({
    title: '', description: '', experience: '', skills: '', startDate: '', endDate: '', salary: '', jobType: JobType.FULL_TIME, location: '', openings: 1
  });
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);

  const [filters, setFilters] = useState<JobFilters>({
    companyName: '', location: '', experience: '', role: '', skills: ''
  });

  const [adminAuthForm, setAdminAuthForm] = useState({
    companyEmail: '', companyName: '', employerId: '', employerName: '', password: ''
  });
  
  const [userAuthForm, setUserAuthForm] = useState({
    email: '', name: '', degree: '', class12: '', class10: '', phone: '', address: '', password: '', resume: null as File | null
  });

  const [selectedJob, setSelectedJob] = useState<JobPost | null>(null);
  const [showJobModal, setShowJobModal] = useState(false);
  const [showResumeModal, setShowResumeModal] = useState(false);
  const [tempResume, setTempResume] = useState<File | null>(null);

  // --- EFFECTS ---
  
  // Fetch Jobs on Mount and when view changes to dashboards
  useEffect(() => {
    if (currentView === 'admin-dash' || currentView === 'user-dash' || currentView === 'landing') {
      fetchJobs();
    }
  }, [currentView]);

  const fetchJobs = async () => {
    const response = await api.getJobs();
    if (response.success && response.data) {
      setJobs(response.data);
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setUserRole(UserRole.GUEST);
    setCurrentView('landing');
    setSavedJobs([]);
    setErrors({});
  };

  // --- ADMIN ACTIONS ---
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const newErrors: Record<string, string> = {};
    if (!validators.required(adminAuthForm.employerId)) newErrors.employerId = "Employer ID is required";
    if (!validators.required(adminAuthForm.password)) newErrors.password = "Password is required";
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setLoading(false);
      return;
    }

    const response = await api.adminLogin(adminAuthForm.employerId, adminAuthForm.password);
    
    if (response.success && response.data) {
      setCurrentUser(response.data);
      setUserRole(UserRole.ADMIN);
      setCurrentView('admin-dash');
      setErrors({});
    } else {
      setErrors({ form: response.message || "Login Failed" });
    }
    setLoading(false);
  };

  const handleAdminSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const newErrors: Record<string, string> = {};
    if (!validators.email(adminAuthForm.companyEmail)) newErrors.companyEmail = "Invalid email format";
    if (!validators.required(adminAuthForm.companyName)) newErrors.companyName = "Company Name required";
    if (!validators.required(adminAuthForm.employerId)) newErrors.employerId = "Employer ID required";
    if (!validators.required(adminAuthForm.employerName)) newErrors.employerName = "Your Name required";
    if (!validators.password(adminAuthForm.password)) newErrors.password = "Password must be at least 6 chars";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setLoading(false);
      return;
    }

    const response = await api.adminSignup(adminAuthForm);
    
    if (response.success && response.data) {
      setCurrentUser(response.data);
      setUserRole(UserRole.ADMIN);
      setCurrentView('admin-dash');
      setErrors({});
    } else {
      setErrors({ form: response.message || "Signup Failed" });
    }
    setLoading(false);
  };

  const handleGenerateDescription = async () => {
    if (!jobForm.title || !jobForm.skills) {
      setErrors({ ...errors, descriptionGen: "Title and Skills required for AI" });
      return;
    }
    setIsGeneratingAI(true);
    setErrors({ ...errors, descriptionGen: "" }); 
    try {
      const desc = await generateJobDescription(jobForm.title, jobForm.skills, jobForm.experience);
      setJobForm(prev => ({ ...prev, description: desc }));
    } catch (e) {
      setErrors({ ...errors, descriptionGen: "AI Generation failed. Try again." });
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const handlePostJob = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const newErrors: Record<string, string> = {};
    if (!validators.required(jobForm.title)) newErrors.title = "Job Title is required";
    if (!validators.required(jobForm.description)) newErrors.description = "Description is required";
    if (!validators.required(jobForm.experience)) newErrors.experience = "Experience is required";
    if (!validators.required(jobForm.skills)) newErrors.skills = "Skills are required";
    if (!validators.required(jobForm.salary)) newErrors.salary = "Salary is required";
    if (!validators.required(jobForm.location)) newErrors.location = "Location is required";
    if (!validators.required(jobForm.startDate)) newErrors.startDate = "Start Date is required";
    if (!validators.required(jobForm.endDate)) newErrors.endDate = "End Date is required";
    if (!validators.dateSequence(jobForm.startDate, jobForm.endDate)) newErrors.endDate = "End Date must be after Start Date";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setLoading(false);
      return;
    }

    const admin = currentUser as AdminProfile;
    const jobData: Partial<JobPost> = {
      employerId: admin.employerId,
      employerName: admin.employerName,
      companyName: admin.companyName,
      title: jobForm.title,
      description: jobForm.description,
      experienceRequired: jobForm.experience,
      skillset: jobForm.skills.split(',').map(s => s.trim()),
      startDate: jobForm.startDate,
      endDate: jobForm.endDate,
      salary: jobForm.salary,
      jobType: jobForm.jobType,
      location: jobForm.location,
      openings: Number(jobForm.openings)
    };

    const response = await api.postJob(jobData);

    if (response.success) {
      fetchJobs(); // Reload jobs
      setJobForm({
        title: '', description: '', experience: '', skills: '', startDate: '', endDate: '', salary: '', jobType: JobType.FULL_TIME, location: '', openings: 1
      });
      setErrors({});
      alert("Job Posted Successfully!");
    } else {
      setErrors({ form: response.message || "Failed to post job" });
    }
    setLoading(false);
  };

  const toggleWithdrawJob = async (jobId: string, currentStatus: boolean) => {
    await api.withdrawJob(jobId, !currentStatus);
    fetchJobs();
  };

  // --- USER ACTIONS ---
  const handleUserLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const newErrors: Record<string, string> = {};
    if (!validators.required(userAuthForm.email)) newErrors.email = "Email/Phone is required";
    if (!validators.required(userAuthForm.password)) newErrors.password = "Password is required";
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setLoading(false);
      return;
    }

    const response = await api.userLogin(userAuthForm.email, userAuthForm.password);
    
    if (response.success && response.data) {
      setCurrentUser(response.data);
      setUserRole(UserRole.USER);
      setCurrentView('user-dash');
      setErrors({});
    } else {
      setErrors({ form: response.message || "Login Failed" });
    }
    setLoading(false);
  };

  const handleUserSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const newErrors: Record<string, string> = {};
    if (!validators.required(userAuthForm.name)) newErrors.name = "Name required";
    if (!validators.email(userAuthForm.email)) newErrors.email = "Invalid email";
    if (!validators.phone(userAuthForm.phone)) newErrors.phone = "Invalid phone (10 digits)";
    if (!validators.required(userAuthForm.address)) newErrors.address = "Address required";
    if (!validators.required(userAuthForm.degree)) newErrors.degree = "Degree required";
    if (!validators.required(userAuthForm.class12)) newErrors.class12 = "Class 12 % required";
    if (!validators.required(userAuthForm.class10)) newErrors.class10 = "Class 10 % required";
    if (!userAuthForm.resume) newErrors.resume = "Resume upload required";
    if (!validators.password(userAuthForm.password)) newErrors.password = "Password min 6 chars";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      setLoading(false);
      return;
    }

    const userData = {
      email: userAuthForm.email,
      name: userAuthForm.name,
      education: { degree: userAuthForm.degree, class12: userAuthForm.class12, class10: userAuthForm.class10 },
      phoneNumber: userAuthForm.phone,
      address: userAuthForm.address,
      password: userAuthForm.password,
      resumeName: userAuthForm.resume ? userAuthForm.resume.name : null
    };

    const response = await api.userSignup(userData);

    if (response.success && response.data) {
      setCurrentUser(response.data);
      setUserRole(UserRole.USER);
      setCurrentView('user-dash');
      setErrors({});
    } else {
      setErrors({ form: response.message || "Signup Failed" });
    }
    setLoading(false);
  };

  const handleResumeUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        setErrors(prev => ({ ...prev, resume: "Only PDF files allowed" }));
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        setErrors(prev => ({ ...prev, resume: "File size must be < 10MB" }));
        return;
      }
      setUserAuthForm(prev => ({ ...prev, resume: file }));
      setErrors(prev => ({ ...prev, resume: "" }));
    }
  };

  const applyForJob = async (jobId: string) => {
    if (!currentUser) return;
    setLoading(true);
    const response = await api.applyForJob(jobId, currentUser._id, (currentUser as UserProfile).email);
    if (response.success) {
      alert("Application Sent Successfully! 🚀 A confirmation email has been sent.");
      fetchJobs(); // Update counts
    } else {
      alert(response.message);
    }
    setLoading(false);
  };

  const toggleSaveJob = (jobId: string) => {
    setSavedJobs(prev => prev.includes(jobId) ? prev.filter(id => id !== jobId) : [...prev, jobId]);
  };

  // --- FILTERS ---
  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      if (job.isWithdrawn) return false;
      const matchCompany = filters.companyName ? job.companyName.toLowerCase().includes(filters.companyName.toLowerCase()) : true;
      const matchRole = filters.role ? job.title.toLowerCase().includes(filters.role.toLowerCase()) : true;
      const matchLoc = filters.location ? job.location.toLowerCase().includes(filters.location.toLowerCase()) : true;
      const matchExp = filters.experience ? job.experienceRequired.toLowerCase().includes(filters.experience.toLowerCase()) : true;
      const matchSkill = filters.skills ? job.skillset.some(s => s.toLowerCase().includes(filters.skills.toLowerCase())) : true;
      return matchCompany && matchRole && matchLoc && matchExp && matchSkill;
    });
  }, [jobs, filters]);

  const adminJobs = useMemo(() => {
    if (!currentUser || userRole !== UserRole.ADMIN) return [];
    return jobs.filter(j => j.employerId === (currentUser as AdminProfile).employerId);
  }, [jobs, currentUser, userRole]);


  // --- RENDERERS ---

  const renderLanding = () => (
    <div className="flex flex-col min-h-screen bg-slate-50 relative overflow-hidden">
      {/* Animated Background Blobs */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute -top-40 -right-40 w-[600px] h-[600px] bg-indigo-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-float"></div>
        <div className="absolute top-40 -left-40 w-[500px] h-[500px] bg-purple-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-float-delayed"></div>
      </div>

      <nav className="px-6 py-5 flex justify-between items-center max-w-7xl mx-auto w-full glass rounded-b-2xl shadow-sm sticky top-0 z-50">
        <div className="flex items-center space-x-2 text-indigo-600">
          <div className="bg-indigo-600 text-white p-2 rounded-lg shadow-lg">
             <Building2 className="w-6 h-6" />
          </div>
          <span className="text-2xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-violet-600">JobNexus</span>
        </div>
        <div className="space-x-4">
          <Button variant="ghost" onClick={() => { setAuthMode('login'); setErrors({}); setCurrentView('user-auth'); }}>Job Seeker</Button>
          <Button variant="primary" onClick={() => { setAuthMode('login'); setErrors({}); setCurrentView('admin-auth'); }}>Employer Portal</Button>
        </div>
      </nav>

      <div className="flex-1 flex flex-col items-center justify-center text-center px-4 py-20">
        <div className="inline-block mb-4 px-4 py-1.5 bg-indigo-100 text-indigo-700 rounded-full text-sm font-semibold tracking-wide animate-fade-in">
          ✨ The Future of Hiring is Here
        </div>
        <h1 className="text-6xl md:text-7xl font-extrabold text-slate-900 mb-6 leading-tight animate-fade-in" style={{animationDelay: '0.1s'}}>
          Find Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">Dream Job</span> <br/>
          Faster Than Ever.
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mb-10 animate-fade-in leading-relaxed" style={{animationDelay: '0.2s'}}>
          Connect with top employers and discover opportunities tailored to your skills using our AI-powered matching engine.
        </p>
        <div className="flex gap-4 animate-fade-in" style={{animationDelay: '0.3s'}}>
          <Button className="px-10 py-4 text-lg shadow-xl shadow-indigo-200" onClick={() => { setAuthMode('signup'); setErrors({}); setCurrentView('user-auth'); }}>
            Get Started Now
          </Button>
          <Button variant="outline" className="px-10 py-4 text-lg bg-white" onClick={() => window.scrollTo({ top: 800, behavior: 'smooth'})}>
            Explore Jobs
          </Button>
        </div>

        {/* Feature Highlights */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto w-full px-4 animate-fade-in" style={{animationDelay: '0.5s'}}>
           {[
             { icon: <Stars className="w-6 h-6"/>, title: "AI-Powered", desc: "Smart matching for better relevance." },
             { icon: <ShieldCheck className="w-6 h-6"/>, title: "Verified Jobs", desc: "Trustworthy employers only." },
             { icon: <TrendingUp className="w-6 h-6"/>, title: "Career Growth", desc: "Tools to boost your career." }
           ].map((f, i) => (
             <div key={i} className="p-6 bg-white rounded-2xl shadow-lg border border-slate-100 hover:-translate-y-1 transition-transform">
                <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 mb-4 mx-auto">{f.icon}</div>
                <h3 className="font-bold text-slate-900 mb-2">{f.title}</h3>
                <p className="text-slate-500 text-sm">{f.desc}</p>
             </div>
           ))}
        </div>
      </div>
    </div>
  );

  const renderAuthContainer = (title: string, formContent: React.ReactNode, isLogin: boolean, onSwitch: () => void) => (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-100 to-indigo-100 py-12 px-4 relative overflow-hidden">
       {/* Decorative Circles */}
       <div className="absolute top-10 left-10 w-64 h-64 bg-indigo-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float"></div>
       <div className="absolute bottom-10 right-10 w-64 h-64 bg-violet-400 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-float-delayed"></div>

      <div className="max-w-md w-full glass p-8 rounded-2xl shadow-2xl border-t border-white relative z-10 animate-fade-in">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">{title}</h2>
          <p className="text-slate-500 mt-2 text-sm">Welcome to JobNexus</p>
        </div>
        {errors.form && (
          <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-4 text-center border border-red-100 animate-fade-in">
            {errors.form}
          </div>
        )}
        {formContent}
        <div className="text-center text-sm mt-6 pt-6 border-t border-slate-200">
          <button onClick={onSwitch} className="text-indigo-600 hover:text-indigo-800 font-bold transition-colors">
            {isLogin ? "Don't have an account? Create one" : "Already have an account? Sign In"}
          </button>
          <div className="mt-4">
             <button onClick={() => { setCurrentView('landing'); setErrors({}); }} className="text-slate-400 hover:text-slate-600 flex items-center justify-center mx-auto gap-1">
               <LogOut className="w-3 h-3 rotate-180" /> Back to Home
             </button>
          </div>
        </div>
      </div>
    </div>
  );

  const renderAdminAuth = () => renderAuthContainer(
    authMode === 'login' ? 'Employer Login' : 'Employer Registration',
    <form className="space-y-4" onSubmit={authMode === 'login' ? handleAdminLogin : handleAdminSignup}>
      {authMode === 'signup' && (
        <>
           <Input label="Company Email" type="email" value={adminAuthForm.companyEmail} onChange={e => setAdminAuthForm({...adminAuthForm, companyEmail: e.target.value})} error={errors.companyEmail} />
           <Input label="Company Name" value={adminAuthForm.companyName} onChange={e => setAdminAuthForm({...adminAuthForm, companyName: e.target.value})} error={errors.companyName} />
           <Input label="Your Name" value={adminAuthForm.employerName} onChange={e => setAdminAuthForm({...adminAuthForm, employerName: e.target.value})} error={errors.employerName} />
        </>
      )}
      <Input label={authMode === 'login' ? "Employer ID / Email" : "Create Employer ID"} value={adminAuthForm.employerId} onChange={e => setAdminAuthForm({...adminAuthForm, employerId: e.target.value})} error={errors.employerId} />
      <Input label="Password" type="password" value={adminAuthForm.password} onChange={e => setAdminAuthForm({...adminAuthForm, password: e.target.value})} error={errors.password} />
      <Button type="submit" loading={loading} fullWidth className="mt-6 shadow-indigo-500/40">{authMode === 'login' ? 'Sign In' : 'Register Company'}</Button>
    </form>,
    authMode === 'login',
    () => { setAuthMode(authMode === 'login' ? 'signup' : 'login'); setErrors({}); }
  );

  const renderUserAuth = () => (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 to-slate-100 py-12 px-4">
      <div className={`w-full max-w-4xl glass rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row animate-fade-in border border-white/50`}>
        {/* Left Side Image/Info */}
        <div className="md:w-5/12 bg-gradient-to-br from-indigo-600 to-violet-700 p-10 text-white flex flex-col justify-between relative overflow-hidden">
           <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
           <div className="relative z-10">
             <h2 className="text-3xl font-bold mb-4">Start your journey</h2>
             <p className="text-indigo-100">Join thousands of professionals finding their dream jobs every day.</p>
           </div>
           <div className="relative z-10 mt-8">
              <div className="flex items-center gap-3 bg-white/10 p-4 rounded-xl backdrop-blur-md border border-white/10">
                 <div className="w-10 h-10 rounded-full bg-green-400 flex items-center justify-center shadow-lg">✓</div>
                 <div className="text-sm">
                    <div className="font-bold">100% Free</div>
                    <div className="opacity-80">For job seekers</div>
                 </div>
              </div>
           </div>
        </div>

        {/* Right Side Form */}
        <div className="md:w-7/12 p-10 bg-white/80">
          <h2 className="text-2xl font-bold text-slate-800 mb-6">{authMode === 'login' ? 'Welcome Back!' : 'Create Your Profile'}</h2>
          
          {errors.form && (
            <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-6 border border-red-100">
              {errors.form}
            </div>
          )}

          <form className="space-y-4" onSubmit={authMode === 'login' ? handleUserLogin : handleUserSignup}>
            {authMode === 'signup' ? (
              <div className="space-y-6 h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                   <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-wider mb-3">Personal Info</h3>
                   <div className="space-y-3">
                      <Input label="Full Name" value={userAuthForm.name} onChange={e => setUserAuthForm({...userAuthForm, name: e.target.value})} error={errors.name} />
                      <div className="grid grid-cols-2 gap-3">
                         <Input label="Email" type="email" value={userAuthForm.email} onChange={e => setUserAuthForm({...userAuthForm, email: e.target.value})} error={errors.email} />
                         <Input label="Phone" value={userAuthForm.phone} onChange={e => setUserAuthForm({...userAuthForm, phone: e.target.value})} error={errors.phone} />
                      </div>
                      <Input label="Address" value={userAuthForm.address} onChange={e => setUserAuthForm({...userAuthForm, address: e.target.value})} error={errors.address} />
                   </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-wider mb-3">Education</h3>
                  <Input label="Degree" placeholder="B.Tech" value={userAuthForm.degree} onChange={e => setUserAuthForm({...userAuthForm, degree: e.target.value})} error={errors.degree} />
                  <div className="grid grid-cols-2 gap-3">
                    <Input label="Class 12 %" value={userAuthForm.class12} onChange={e => setUserAuthForm({...userAuthForm, class12: e.target.value})} error={errors.class12} />
                    <Input label="Class 10 %" value={userAuthForm.class10} onChange={e => setUserAuthForm({...userAuthForm, class10: e.target.value})} error={errors.class10} />
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                  <h3 className="text-sm font-bold text-indigo-600 uppercase tracking-wider mb-3">Documents & Security</h3>
                  <div className="mb-4">
                    <label className="block text-sm font-semibold text-slate-600 mb-1">Resume (PDF)</label>
                    <div className="relative border-2 border-dashed border-slate-300 rounded-xl p-6 hover:bg-indigo-50 transition-colors text-center group">
                       <input type="file" accept=".pdf" onChange={handleResumeUpload} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"/>
                       <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2 group-hover:text-indigo-500"/>
                       <p className="text-sm text-slate-500">{userAuthForm.resume ? userAuthForm.resume.name : "Click to upload or drag and drop"}</p>
                    </div>
                    {errors.resume && <p className="text-red-500 text-xs mt-1">{errors.resume}</p>}
                  </div>
                  <Input label="Password" type="password" value={userAuthForm.password} onChange={e => setUserAuthForm({...userAuthForm, password: e.target.value})} error={errors.password} />
                </div>
              </div>
            ) : (
               <div className="space-y-4">
                  <Input label="Email or Phone" value={userAuthForm.email} onChange={e => setUserAuthForm({...userAuthForm, email: e.target.value})} error={errors.email} />
                  <Input label="Password" type="password" value={userAuthForm.password} onChange={e => setUserAuthForm({...userAuthForm, password: e.target.value})} error={errors.password} />
               </div>
            )}
            
            <Button type="submit" loading={loading} fullWidth className="mt-4 shadow-indigo-500/40">{authMode === 'login' ? 'Login' : 'Create Account'}</Button>
          </form>
          
          <div className="text-center mt-6">
            <button onClick={() => { setAuthMode(authMode === 'login' ? 'signup' : 'login'); setErrors({}); }} className="text-sm text-indigo-600 font-semibold hover:underline">
               {authMode === 'login' ? "Create New Account" : "Already have an account?"}
            </button>
             <div className="mt-2">
               <button onClick={() => { setCurrentView('landing'); setErrors({}); }} className="text-xs text-slate-400 hover:text-slate-600">Back to Home</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderAdminDashboard = () => (
    <div className="min-h-screen bg-slate-50/50">
      <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-30 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-100 rounded-lg text-indigo-700">
               <Briefcase className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold text-slate-800">Employer Portal</h1>
          </div>
          <div className="flex items-center gap-4">
             <div className="text-right hidden sm:block">
                <p className="text-sm font-bold text-slate-800">{(currentUser as AdminProfile)?.companyName}</p>
                <p className="text-xs text-slate-500">ID: {(currentUser as AdminProfile)?.employerId}</p>
             </div>
             <Button variant="ghost" className="text-red-500 hover:bg-red-50 hover:text-red-600" onClick={handleLogout}><LogOut className="w-5 h-5"/></Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar / Post Job */}
        <div className="lg:col-span-4 xl:col-span-3">
          <div className="bg-white p-6 rounded-2xl shadow-xl shadow-slate-200/50 sticky top-24 border border-slate-100">
            <h2 className="text-lg font-bold mb-6 flex items-center gap-2 text-slate-800">
               <span className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white rounded-md p-1"><Building2 className="w-4 h-4"/></span>
               Post New Job
            </h2>
            <form onSubmit={handlePostJob} className="space-y-4">
              <Input label="Job Title" value={jobForm.title} onChange={e => setJobForm({...jobForm, title: e.target.value})} error={errors.title} />
              
              <div className="relative">
                 <div className="flex justify-between items-center mb-1.5">
                    <label className="text-sm font-semibold text-slate-600">Description</label>
                    <button type="button" onClick={handleGenerateDescription} className="text-xs flex items-center text-violet-600 hover:text-violet-800 font-bold bg-violet-50 px-2 py-1 rounded-md transition-colors disabled:opacity-50" disabled={isGeneratingAI}>
                      <Wand2 className="w-3 h-3 mr-1"/> {isGeneratingAI ? 'Writing...' : 'AI Generate'}
                    </button>
                 </div>
                 <textarea 
                   className={`w-full px-4 py-3 bg-white border rounded-xl text-slate-800 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none h-32 transition-all ${errors.description ? 'border-red-300' : 'border-slate-200'}`}
                   value={jobForm.description} 
                   onChange={e => setJobForm({...jobForm, description: e.target.value})}
                   placeholder="Enter details..."
                 />
                 {errors.descriptionGen && <p className="text-xs text-red-500 mt-1">{errors.descriptionGen}</p>}
                 {errors.description && <p className="text-xs text-red-500 mt-1">{errors.description}</p>}
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <Input label="Experience" placeholder="e.g. 3-5 Yrs" value={jobForm.experience} onChange={e => setJobForm({...jobForm, experience: e.target.value})} error={errors.experience} />
                <Input label="Salary" placeholder="$80k" value={jobForm.salary} onChange={e => setJobForm({...jobForm, salary: e.target.value})} error={errors.salary} />
              </div>
              <Input label="Skills (Comma separated)" placeholder="React, Node..." value={jobForm.skills} onChange={e => setJobForm({...jobForm, skills: e.target.value})} error={errors.skills} />
              
              <div className="grid grid-cols-2 gap-3">
                <Input label="Start Date" type="date" value={jobForm.startDate} onChange={e => setJobForm({...jobForm, startDate: e.target.value})} error={errors.startDate} />
                <Input label="End Date" type="date" value={jobForm.endDate} onChange={e => setJobForm({...jobForm, endDate: e.target.value})} error={errors.endDate} />
              </div>

              <div className="grid grid-cols-2 gap-3">
                 <div className="mb-4">
                    <label className="block text-sm font-semibold text-slate-600 mb-1.5">Type</label>
                    <select className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-800 focus:ring-2 focus:ring-indigo-500 outline-none appearance-none" value={jobForm.jobType} onChange={e => setJobForm({...jobForm, jobType: e.target.value as JobType})}>
                      {Object.values(JobType).map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                 </div>
                 <Input label="Location" value={jobForm.location} onChange={e => setJobForm({...jobForm, location: e.target.value})} error={errors.location} />
              </div>
              <Input label="Openings" type="number" min="1" value={jobForm.openings} onChange={e => setJobForm({...jobForm, openings: parseInt(e.target.value)})} />
              
              <Button type="submit" loading={loading} fullWidth className="shadow-indigo-500/30 mt-2">Publish Job</Button>
            </form>
          </div>
        </div>

        {/* Job Feed */}
        <div className="lg:col-span-8 xl:col-span-9 space-y-6">
          <div className="flex justify-between items-end border-b border-slate-200 pb-4 mb-6">
             <div>
                <h2 className="text-2xl font-bold text-slate-800">Your Listings</h2>
                <p className="text-slate-500 mt-1">Manage your active jobs and view applications.</p>
             </div>
             <div className="bg-indigo-50 px-4 py-2 rounded-lg text-indigo-700 font-bold">
                Total Active: {adminJobs.filter(j => !j.isWithdrawn).length}
             </div>
          </div>

          {adminJobs.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-3xl border-2 border-dashed border-slate-200">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                 <Briefcase className="w-8 h-8 text-slate-300" />
              </div>
              <h3 className="text-lg font-bold text-slate-700">No Jobs Posted Yet</h3>
              <p className="text-slate-500 max-w-xs mx-auto mt-2">Use the form on the left to create your first job listing and attract top talent.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {adminJobs.map(job => (
              <div key={job._id} className={`group relative bg-white rounded-2xl p-6 border transition-all duration-300 ${job.isWithdrawn ? 'border-slate-200 opacity-75' : 'border-slate-200 hover:border-indigo-300 shadow-sm hover:shadow-xl hover:-translate-y-1'}`}>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{job.title}</h3>
                    <div className="flex items-center gap-2 text-xs text-slate-500 mt-1 font-medium uppercase tracking-wide">
                      <span className="bg-slate-100 px-2 py-0.5 rounded">{job.location}</span>
                      <span>&bull;</span>
                      <span className="bg-slate-100 px-2 py-0.5 rounded">{job.jobType}</span>
                    </div>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-xs font-bold shadow-sm ${job.isWithdrawn ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-green-50 text-green-600 border border-green-100'}`}>
                    {job.isWithdrawn ? 'Withdrawn' : 'Active'}
                  </div>
                </div>
                
                <div className="bg-slate-50 rounded-xl p-4 grid grid-cols-3 gap-4 mb-6 border border-slate-100">
                  <div className="text-center">
                     <span className="block text-2xl font-bold text-indigo-600">{job.applicationCount}</span>
                     <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Applied</span>
                  </div>
                  <div className="text-center border-l border-slate-200">
                     <span className="block text-2xl font-bold text-slate-700">{job.openings}</span>
                     <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Openings</span>
                  </div>
                  <div className="text-center border-l border-slate-200">
                     <span className="block text-2xl font-bold text-slate-700">{job.skillset.length}</span>
                     <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Skills</span>
                  </div>
                </div>

                <div className="flex gap-3">
                   <Button 
                      variant="secondary" 
                      className="flex-1 text-xs" 
                      onClick={() => { setSelectedJob(job); setShowJobModal(true); }}
                    >
                      View Details
                    </Button>
                   <Button 
                      variant={job.isWithdrawn ? 'outline' : 'danger'} 
                      className="flex-1 text-xs"
                      onClick={() => toggleWithdrawJob(job._id, job.isWithdrawn)}
                    >
                      {job.isWithdrawn ? 'Repost' : 'Withdraw'}
                    </Button>
                </div>
              </div>
            ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );

  const renderUserDashboard = () => (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Sticky Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
             <div className="flex items-center gap-3 w-full md:w-auto">
                <div className="bg-indigo-600 p-2 rounded-lg text-white shadow-lg shadow-indigo-200">
                   <Search className="w-5 h-5"/>
                </div>
                <div className="relative w-full md:w-[400px] group">
                  <input 
                    type="text" 
                    placeholder="Search jobs by company name..." 
                    className="w-full pl-4 pr-10 py-2.5 rounded-xl bg-slate-100 border-transparent focus:bg-white focus:border-indigo-300 focus:ring-4 focus:ring-indigo-100 transition-all outline-none font-medium text-slate-700 placeholder-slate-400"
                    value={filters.companyName}
                    onChange={e => setFilters({...filters, companyName: e.target.value})}
                  />
                  <span className="absolute right-3 top-3 text-slate-400 group-focus-within:text-indigo-500">⌘K</span>
                </div>
             </div>

             <div className="flex items-center gap-4 w-full md:w-auto justify-end">
                <div className="hidden md:block text-right">
                   <p className="text-sm font-bold text-slate-800">{(currentUser as UserProfile).name}</p>
                   <p className="text-xs text-slate-500">{(currentUser as UserProfile).email}</p>
                </div>
                <div className="h-10 w-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold shadow-lg">
                  {(currentUser as UserProfile).name.charAt(0)}
                </div>
                <Button variant="ghost" className="text-slate-500 hover:text-red-500" onClick={handleLogout}><LogOut className="w-5 h-5"/></Button>
             </div>
          </div>

          {/* Filter Bar */}
          <div className="mt-4 flex overflow-x-auto pb-2 gap-2 no-scrollbar items-center">
             <div className="flex items-center text-xs font-bold text-slate-500 uppercase mr-2">
               <Filter className="w-3 h-3 mr-1" /> Filters
             </div>
             {['Location', 'Role', 'Experience', 'Skills'].map((placeholder) => (
               <input 
                  key={placeholder}
                  placeholder={placeholder} 
                  className="px-4 py-1.5 text-sm bg-white border border-slate-200 rounded-full min-w-[120px] focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 outline-none transition-all"
                  value={filters[placeholder.toLowerCase() as keyof JobFilters]} 
                  onChange={e => setFilters({...filters, [placeholder.toLowerCase()]: e.target.value})} 
               />
             ))}
             <Button variant="ghost" className="text-xs text-red-500 hover:bg-red-50 ml-auto whitespace-nowrap" onClick={() => setFilters({companyName:'', location:'', role:'', experience:'', skills:''})}>Clear All</Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {savedJobs.length > 0 && (
           <div className="mb-12 animate-fade-in">
              <h2 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
                 <Heart className="w-5 h-5 text-red-500 fill-current"/> Saved Jobs <span className="text-sm font-normal text-slate-400 ml-2">({savedJobs.length})</span>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 {jobs.filter(j => savedJobs.includes(j._id)).map(job => renderJobCard(job, true))}
              </div>
              <div className="h-px bg-slate-200 my-8"></div>
           </div>
        )}

        <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
           <TrendingUp className="w-5 h-5 text-indigo-600"/> Recommended Jobs
        </h2>
        
        {loading ? (
          <div className="flex justify-center py-20">
             <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredJobs.length > 0 ? (
              filteredJobs.map(job => renderJobCard(job))
            ) : (
              <div className="col-span-full text-center py-24">
                 <div className="bg-slate-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-10 h-10 text-slate-400" />
                 </div>
                 <h3 className="text-lg font-bold text-slate-700">No Jobs Found</h3>
                 <p className="text-slate-500">Try adjusting your filters to see more results.</p>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );

  const renderJobCard = (job: JobPost, isSavedView = false) => (
    <div key={job._id} className="card-3d bg-white rounded-2xl p-0 border border-slate-100 relative group flex flex-col h-full overflow-hidden shadow-sm">
      <div className="p-6 flex-1 relative z-10">
         <div className="flex justify-between items-start mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-slate-100 to-slate-200 rounded-lg flex items-center justify-center font-bold text-slate-600 text-xl shadow-inner">
               {job.companyName.charAt(0)}
            </div>
            <button 
              onClick={(e) => { e.stopPropagation(); toggleSaveJob(job._id); }}
              className="p-2 rounded-full hover:bg-slate-50 transition-colors"
            >
              <Heart className={`w-5 h-5 transition-colors ${savedJobs.includes(job._id) ? 'text-red-500 fill-current' : 'text-slate-300 hover:text-red-400'}`} />
            </button>
         </div>

         <h3 className="text-lg font-bold text-slate-900 mb-1 line-clamp-1 group-hover:text-indigo-600 transition-colors">{job.title}</h3>
         <p className="text-sm font-medium text-slate-500 mb-4">{job.companyName}</p>

         <div className="flex flex-wrap gap-2 mb-6">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-50 text-indigo-700">
              <MapPin className="w-3 h-3 mr-1"/> {job.location}
            </span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-50 text-emerald-700">
              <DollarSign className="w-3 h-3 mr-1"/> {job.salary}
            </span>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-50 text-purple-700">
              <Briefcase className="w-3 h-3 mr-1"/> {job.experienceRequired}
            </span>
         </div>

         <div className="flex flex-wrap gap-1.5">
            {job.skillset.slice(0, 3).map(s => (
               <span key={s} className="text-[11px] px-2 py-1 bg-slate-50 border border-slate-100 rounded-md text-slate-600 font-medium">{s}</span>
            ))}
            {job.skillset.length > 3 && <span className="text-[11px] px-2 py-1 text-slate-400">+{job.skillset.length - 3}</span>}
         </div>
      </div>

      <div className="p-4 border-t border-slate-100 bg-slate-50/50 grid grid-cols-2 gap-3">
         <Button variant="outline" className="text-xs bg-white" onClick={() => { setSelectedJob(job); setShowJobModal(true); }}>
            Details
         </Button>
         <div className="col-span-2 flex gap-2 mt-2">
            <Button variant="secondary" className="text-xs flex-1" onClick={() => { setSelectedJob(job); setShowResumeModal(true); }}>
              Modify Resume
            </Button>
            <Button className="text-xs flex-1 shadow-indigo-200" onClick={() => applyForJob(job._id)}>
               Apply Now
            </Button>
         </div>
      </div>
    </div>
  );

  // --- ROUTING ---
  let content;
  switch (currentView) {
    case 'admin-auth': content = renderAdminAuth(); break;
    case 'admin-dash': content = renderAdminDashboard(); break;
    case 'user-auth': content = renderUserAuth(); break;
    case 'user-dash': content = renderUserDashboard(); break;
    default: content = renderLanding();
  }

  return (
    <>
      {content}

      {/* Job Details Modal */}
      <Modal isOpen={showJobModal} onClose={() => setShowJobModal(false)} title={selectedJob?.title || 'Job Details'}>
        {selectedJob && (
          <div className="space-y-6">
            <div className="flex items-start justify-between pb-4 border-b border-slate-100">
               <div>
                 <h4 className="text-2xl font-bold text-slate-800">{selectedJob.companyName}</h4>
                 <div className="flex items-center text-slate-500 text-sm mt-1">
                    <MapPin className="w-4 h-4 mr-1"/> {selectedJob.location}
                 </div>
               </div>
               <div className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-lg font-bold text-sm">
                  {selectedJob.jobType}
               </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm">
               <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="block text-slate-400 text-xs uppercase font-bold mb-1">Salary</span>
                  <span className="font-semibold text-slate-800">{selectedJob.salary}</span>
               </div>
               <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="block text-slate-400 text-xs uppercase font-bold mb-1">Experience</span>
                  <span className="font-semibold text-slate-800">{selectedJob.experienceRequired}</span>
               </div>
               <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="block text-slate-400 text-xs uppercase font-bold mb-1">Start Date</span>
                  <span className="font-semibold text-slate-800">{selectedJob.startDate}</span>
               </div>
               <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="block text-slate-400 text-xs uppercase font-bold mb-1">Closing Date</span>
                  <span className="font-semibold text-slate-800">{selectedJob.endDate}</span>
               </div>
            </div>

            <div>
              <h5 className="font-bold text-slate-900 mb-3 text-sm uppercase tracking-wide">Job Description</h5>
              <div className="prose prose-sm text-slate-600 max-w-none bg-slate-50/50 p-4 rounded-xl border border-slate-100 whitespace-pre-line leading-relaxed">
                {selectedJob.description}
              </div>
            </div>

            <div>
              <h5 className="font-bold text-slate-900 mb-3 text-sm uppercase tracking-wide">Skills Required</h5>
              <div className="flex flex-wrap gap-2">
                {selectedJob.skillset.map(s => (
                  <span key={s} className="bg-white border border-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-sm font-medium shadow-sm">
                    {s}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="pt-6 border-t border-slate-100 flex justify-end gap-3">
               <Button variant="secondary" onClick={() => setShowJobModal(false)}>Close</Button>
               {userRole === UserRole.USER && (
                 <Button className="shadow-indigo-300" onClick={() => { setShowJobModal(false); applyForJob(selectedJob._id); }}>Apply Now</Button>
               )}
            </div>
          </div>
        )}
      </Modal>

      {/* Modify Resume Modal */}
      <Modal isOpen={showResumeModal} onClose={() => { setShowResumeModal(false); setTempResume(null); }} title="Tailor Your Application">
         <div className="space-y-6">
            <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-100 flex items-start gap-3">
               <div className="bg-white p-2 rounded-full shadow-sm text-indigo-600 mt-1">
                 <FileText className="w-4 h-4"/>
               </div>
               <div>
                  <p className="text-sm font-bold text-indigo-900">Current Resume</p>
                  <p className="text-sm text-indigo-700">{(currentUser as UserProfile)?.resumeName || 'No resume uploaded'}</p>
               </div>
            </div>

            <div className="border-2 border-dashed border-slate-300 rounded-2xl p-8 text-center hover:bg-slate-50 transition-colors cursor-pointer relative group">
              <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition-transform">
                 <ArrowRight className="w-5 h-5 text-slate-400 -rotate-90" />
              </div>
              <p className="text-sm font-medium text-slate-700">Upload a tailored resume (PDF)</p>
              <p className="text-xs text-slate-400 mt-1">Max 10MB</p>
              <input type="file" accept=".pdf" onChange={(e) => {
                 const file = e.target.files?.[0];
                 if (file && file.type === 'application/pdf') setTempResume(file);
              }} className="absolute inset-0 opacity-0 cursor-pointer"/>
            </div>

            {tempResume && (
               <div className="flex items-center p-3 bg-green-50 text-green-700 rounded-lg border border-green-200 animate-fade-in">
                  <CheckCircle className="w-5 h-5 mr-2"/>
                  <span className="text-sm font-medium">Selected: {tempResume.name}</span>
                  <button onClick={() => setTempResume(null)} className="ml-auto text-green-800 hover:underline text-xs">Remove</button>
               </div>
            )}

            <div className="flex justify-end gap-3 pt-2">
               <Button variant="ghost" onClick={() => setShowResumeModal(false)}>Cancel</Button>
               <Button disabled={!tempResume} onClick={() => {
                  if (currentUser && tempResume) {
                     setCurrentUser({ ...(currentUser as UserProfile), resumeName: tempResume.name });
                     setTempResume(null);
                     setShowResumeModal(false);
                     alert("Resume updated for this application!");
                  }
               }}>Update & Apply</Button>
            </div>
         </div>
      </Modal>
    </>
  );
}

export default App;