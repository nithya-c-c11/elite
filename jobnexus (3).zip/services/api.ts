import { 
  AdminProfile, 
  UserProfile, 
  JobPost, 
  Application, 
  ApiResponse,
  JobType 
} from '../types';

// --- CONFIGURATION ---
// Set to TRUE to use LocalStorage (Demo Mode). 
// Set to FALSE to use real Node/MongoDB backend (node server.js).
const USE_MOCK_DB = true;
const API_BASE_URL = 'http://localhost:5000/api';

// --- VALIDATION HELPERS ---
export const validators = {
  email: (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),
  phone: (phone: string) => /^\d{10}$/.test(phone),
  password: (pwd: string) => pwd.length >= 6,
  required: (val: any) => val !== null && val !== undefined && val !== '' && (Array.isArray(val) ? val.length > 0 : true),
  dateSequence: (start: string, end: string) => new Date(end) >= new Date(start),
};

// --- MOCK DB SIMULATION (LocalStorage) ---
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

const MockDB = {
  get: (collection: string) => JSON.parse(localStorage.getItem(collection) || '[]'),
  set: (collection: string, data: any[]) => localStorage.setItem(collection, JSON.stringify(data)),
  
  async findOne(collection: string, query: (item: any) => boolean) {
    await delay(300);
    const data = this.get(collection);
    return data.find(query);
  },
  
  async insert(collection: string, item: any) {
    await delay(400);
    const data = this.get(collection);
    const newItem = { ...item, _id: Date.now().toString(), createdAt: new Date().toISOString() };
    data.push(newItem);
    this.set(collection, data);
    return newItem;
  },

  async update(collection: string, id: string, updates: any) {
    await delay(300);
    const data = this.get(collection);
    const index = data.findIndex((i: any) => i._id === id);
    if (index === -1) throw new Error('Item not found');
    
    // Merge updates
    data[index] = { ...data[index], ...updates };
    this.set(collection, data);
    return data[index];
  }
};

// Initialize Mock Data if empty
if (USE_MOCK_DB && MockDB.get('jobs').length === 0) {
  const initialJobs = [
    {
      _id: '1',
      employerId: 'emp1',
      employerName: 'Tech Corp HR',
      companyName: 'Tech Corp',
      title: 'Senior React Engineer',
      description: 'We are looking for an experienced React developer to lead our frontend team.',
      experienceRequired: '5+ Years',
      skillset: ['React', 'TypeScript', 'Tailwind'],
      startDate: '2023-11-01',
      endDate: '2023-12-31',
      salary: '$120,000',
      jobType: 'Full Time',
      location: 'Remote',
      openings: 2,
      applicationCount: 5,
      isWithdrawn: false,
      createdAt: new Date().toISOString()
    }
  ];
  MockDB.set('jobs', initialJobs);
}

// --- API SERVICE ---

export const api = {
  // ADMIN AUTH
  adminSignup: async (data: Omit<AdminProfile, '_id' | 'token'>): Promise<ApiResponse<AdminProfile>> => {
    if (USE_MOCK_DB) {
      const exists = await MockDB.findOne('admins', (a: AdminProfile) => a.employerId === data.employerId);
      if (exists) return { success: false, message: 'Employer ID already exists' };
      
      const newAdmin = await MockDB.insert('admins', data);
      return { success: true, data: { ...newAdmin, token: 'mock-jwt-token' } };
    } else {
      try {
        const res = await fetch(`${API_BASE_URL}/admin/signup`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data)
        });
        return await res.json();
      } catch (e) { return { success: false, message: 'Network Error' }; }
    }
  },

  adminLogin: async (employerId: string, password: string): Promise<ApiResponse<AdminProfile>> => {
    if (USE_MOCK_DB) {
      const admin = await MockDB.findOne('admins', (a: AdminProfile) => a.employerId === employerId && a.password === password);
      if (!admin) return { success: false, message: 'Invalid Credentials' };
      return { success: true, data: { ...admin, token: 'mock-jwt-token' } };
    } else {
      try {
        const res = await fetch(`${API_BASE_URL}/admin/login`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ employerId, password })
        });
        return await res.json();
      } catch (e) { return { success: false, message: 'Network Error' }; }
    }
  },

  // USER AUTH
  userSignup: async (data: Omit<UserProfile, '_id' | 'token'>): Promise<ApiResponse<UserProfile>> => {
    if (USE_MOCK_DB) {
      const exists = await MockDB.findOne('users', (u: UserProfile) => u.email === data.email);
      if (exists) return { success: false, message: 'Email already registered' };
      
      const newUser = await MockDB.insert('users', data);
      return { success: true, data: { ...newUser, token: 'mock-jwt-token' } };
    } else {
      try {
        const res = await fetch(`${API_BASE_URL}/user/signup`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data)
        });
        return await res.json();
      } catch (e) { return { success: false, message: 'Network Error' }; }
    }
  },

  userLogin: async (email: string, password: string): Promise<ApiResponse<UserProfile>> => {
    if (USE_MOCK_DB) {
      const user = await MockDB.findOne('users', (u: UserProfile) => u.email === email && u.password === password);
      if (!user) return { success: false, message: 'Invalid Credentials' };
      return { success: true, data: { ...user, token: 'mock-jwt-token' } };
    } else {
      try {
        const res = await fetch(`${API_BASE_URL}/user/login`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password })
        });
        return await res.json();
      } catch (e) { return { success: false, message: 'Network Error' }; }
    }
  },

  // JOBS
  getJobs: async (): Promise<ApiResponse<JobPost[]>> => {
    if (USE_MOCK_DB) {
      await delay(400);
      const jobs = MockDB.get('jobs');
      return { success: true, data: jobs.reverse() };
    } else {
      try {
        const res = await fetch(`${API_BASE_URL}/jobs`);
        return await res.json();
      } catch (e) { return { success: false, message: 'Failed to fetch jobs' }; }
    }
  },

  postJob: async (jobData: Partial<JobPost>): Promise<ApiResponse<JobPost>> => {
    if (USE_MOCK_DB) {
      const newJob = await MockDB.insert('jobs', {
        ...jobData,
        applicationCount: 0,
        isWithdrawn: false
      });
      return { success: true, data: newJob };
    } else {
      try {
        const res = await fetch(`${API_BASE_URL}/jobs`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(jobData)
        });
        return await res.json();
      } catch (e) { return { success: false, message: 'Failed to post job' }; }
    }
  },

  withdrawJob: async (jobId: string, isWithdrawn: boolean): Promise<ApiResponse<JobPost>> => {
    if (USE_MOCK_DB) {
      const updated = await MockDB.update('jobs', jobId, { isWithdrawn });
      return { success: true, data: updated };
    } else {
      try {
        const res = await fetch(`${API_BASE_URL}/jobs/${jobId}/withdraw`, {
           method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ isWithdrawn })
        });
        return await res.json();
      } catch (e) { return { success: false, message: 'Failed to update job' }; }
    }
  },

  applyForJob: async (jobId: string, userId: string, userEmail: string): Promise<ApiResponse<any>> => {
    if (USE_MOCK_DB) {
      // Check previous application
      const exists = await MockDB.findOne('applications', (a: Application) => a.jobId === jobId && a.userId === userId);
      if (exists) return { success: false, message: 'You have already applied for this job.' };

      await MockDB.insert('applications', { jobId, userId, userEmail, status: 'applied' });
      
      // Increment count on job
      const jobs = MockDB.get('jobs');
      const jobIdx = jobs.findIndex((j: any) => j._id === jobId);
      if (jobIdx !== -1) {
        jobs[jobIdx].applicationCount = (jobs[jobIdx].applicationCount || 0) + 1;
        MockDB.set('jobs', jobs);
      }
      
      return { success: true, message: 'Application sent successfully' };
    } else {
      try {
        const res = await fetch(`${API_BASE_URL}/jobs/${jobId}/apply`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId, userEmail })
        });
        return await res.json();
      } catch (e) { return { success: false, message: 'Application failed' }; }
    }
  }
};