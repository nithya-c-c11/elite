import { GoogleGenAI } from "@google/genai";

// Helper to get AI instance. 
// Note: In a real app, ensure process.env.API_KEY is set. 
// For this demo, we handle the case where it might be missing gracefully in the UI.
const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

export const generateJobDescription = async (
  title: string, 
  skills: string, 
  experience: string
): Promise<string> => {
  const ai = getAIClient();
  if (!ai) {
    console.warn("Gemini API Key missing");
    return "Please configure your API Key to use AI features.";
  }

  try {
    const model = "gemini-2.5-flash";
    const prompt = `Write a professional and attractive job description for a "${title}" role. 
    Required skills: ${skills}. 
    Experience level: ${experience}. 
    Keep it concise, under 200 words, using bullet points for responsibilities.`;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text || "Could not generate description.";
  } catch (error) {
    console.error("Error generating job description:", error);
    throw new Error("Failed to generate description");
  }
};
